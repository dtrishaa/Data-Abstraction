/**
 * 
 */
/**
 * 
 */
module librarymanagementSystem {
	requires java.desktop;
}